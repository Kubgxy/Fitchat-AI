import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import { Eye, EyeOff } from "lucide-react";
import { useTheme } from "../components/ThemeContext";


const Register = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    user_id: "",
    age: "",
    gender: "",
    height: "",
    weight: "",
    health_goal: "",
    activity_level: "",
    medical_conditions: [],
    diet_preference: "ทั่วไป",
    exercise_history: [],
    progress_metrics: {},
    first_name: "",
    last_name: "",
    email: "",
    phone_number: "",
    username: "",
    password: "",
  });
  const { theme, toggleTheme } = useTheme();


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/register",
        formData
      );

      await Swal.fire({
        icon: "success",
        title: "ลงทะเบียนสำเร็จ",
        text: "ยินดีต้อนรับเข้าสู่ระบบ",
        showConfirmButton: false,
        timer: 1500,
      });

      navigate("/login");
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "เกิดข้อผิดพลาด",
        text: error.response?.data?.message || "ไม่สามารถลงทะเบียนได้",
        confirmButtonColor: "#3b82f6",
      });
    }
  };

  const handleThemeChange = () => {
    toggleTheme();
  
    const isDark = theme === 'dark'; // ก่อน toggle = dark → จะเปลี่ยนเป็น light
  
    Swal.fire({
      toast: true,
      position: 'bottom-end',
      icon: isDark ? 'success' : 'info',
      title: isDark ? 'Switched to Dark Mode 🌜' : 'Switched to Light Mode 🌞',
      background: isDark ? '#f4f4f4' : '#1f2937', // bg-white vs bg-gray-800
      color: isDark ? '#111827' : '#f9fafb', // text-black vs text-white
      showConfirmButton: false,
      timer: 1500,
      timerProgressBar: true,
      customClass: {
        popup: 'rounded-xl shadow-lg',
        title: 'text-sm font-medium',
      },
    });
  };

  return (
    <div className="min-h-screen pt-20 px-4 sm:px-6 lg:px-8 dark:bg-gray-100">
      <div className="absolute top-4 right-4 z-50">
        <button
          onClick={handleThemeChange}
          className="relative w-16 h-7 bg-gray-300 dark:bg-gray-700 rounded-full transition-colors duration-300 p-1 flex items-center"
        >
          <div
            className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-300 ${
              theme === "dark" ? "translate-x-8" : ""
            }`}
          ></div>
          <span className="absolute left-1 text-xs">🌞</span>
          <span className="absolute right-1 text-xs">🌙</span>
        </button>
      </div>
      {/* Header */}
      <div className="text-center  mb-[40px]">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white dark:text-gray-800">
          สมัครสมาชิก FitChat AI
        </h1>
      </div>

      {/* กล่องฟอร์ม */}
      <div className="max-w-4xl mx-auto h-[700px] bg-white/10 backdrop-blur-sm rounded-xl shadow-xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto dark:bg-black/40">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* ข้อมูลส่วนตัว */}
          <div className="bg-white/5 p-4 sm:p-6 rounded-lg dark:bg-white/50">
            <h2 className="text-xl font-semibold text-white mb-4 dark:text-black/80">
              ข้อมูลส่วนตัว
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  label: "รหัสผู้ใช้",
                  name: "user_id",
                  type: "text",
                  required: true,
                },
                {
                  label: "ชื่อผู้ใช้",
                  name: "username",
                  type: "text",
                  required: true,
                },
                {
                  label: "ชื่อ",
                  name: "first_name",
                  type: "text",
                  required: true,
                },
                {
                  label: "นามสกุล",
                  name: "last_name",
                  type: "text",
                  required: true,
                },
                {
                  label: "อีเมล",
                  name: "email",
                  type: "email",
                  required: true,
                },
                { label: "เบอร์โทรศัพท์", name: "phone_number", type: "tel" },
              ].map((field) => (
                <div key={field.name}>
                  <label className="block text-gray-200 mb-2 dark:text-black/60">
                    {field.label}
                    {field.required && " *"}
                  </label>
                  <input
                    type={field.type}
                    name={field.name}
                    required={field.required}
                    value={formData[field.name]}
                    onChange={handleChange}
                    className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                  />
                </div>
              ))}
            </div>
          </div>
          {/* ข้อมูลสุขภาพ */}
          <div className="bg-white/5 p-4 sm:p-6 rounded-lg dark:bg-white/50">
            <h2 className="text-xl font-semibold text-white mb-4 dark:text-black/80">
              ข้อมูลสุขภาพ
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* อายุ */}
              <div>
                <label className="block text-gray-200 mb-2 dark:text-black/60">อายุ *</label>
                <input
                  type="number"
                  name="age"
                  required
                  value={formData.age}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                />
              </div>
              {/* เพศ */}
              <div>
                <label className="block text-gray-200 mb-2 dark:text-black/60">เพศ *</label>
                <select
                  name="gender"
                  required
                  value={formData.gender}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                >
                  <option value="">เลือกเพศ</option>
                  <option value="ชาย">ชาย</option>
                  <option value="หญิง">หญิง</option>
                  <option value="อื่นๆ">อื่นๆ</option>
                </select>
              </div>
              {/* ส่วนสูง */}
              <div>
                <label className="block text-gray-200 mb-2 dark:text-black/60">
                  ส่วนสูง (ซม.) *
                </label>
                <input
                  type="number"
                  name="height"
                  required
                  value={formData.height}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                />
              </div>
              {/* น้ำหนัก */}
              <div>
                <label className="block text-gray-200 mb-2 dark:text-black/60">
                  น้ำหนัก (กก.) *
                </label>
                <input
                  type="number"
                  name="weight"
                  required
                  value={formData.weight}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                />
              </div>
              {/* เป้าหมายสุขภาพ */}
              <div>
                <label className="block text-gray-200 mb-2 dark:text-black/60">
                  เป้าหมายสุขภาพ *
                </label>
                <select
                  name="health_goal"
                  required
                  value={formData.health_goal}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                >
                  <option value="">เลือกเป้าหมาย</option>
                  <option value="ลดน้ำหนัก">ลดน้ำหนัก</option>
                  <option value="เพิ่มกล้ามเนื้อ">เพิ่มกล้ามเนื้อ</option>
                  <option value="เพิ่มความแข็งแรง">เพิ่มความแข็งแรง</option>
                  <option value="เพิ่มความอดทน">เพิ่มความอดทน</option>
                  <option value="จัดการโรคประจำตัว">จัดการโรคประจำตัว</option>
                  <option value="เพิ่มสมรรถภาพ">เพิ่มสมรรถภาพ</option>
                </select>
              </div>
              {/* ระดับกิจกรรม */}
              <div>
                <label className="block text-gray-200 mb-2 dark:text-black/60">
                  ระดับการออกกำลังกาย *
                </label>
                <select
                  name="activity_level"
                  required
                  value={formData.activity_level}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                >
                  <option value="">เลือกระดับ</option>
                  <option value="ไม่ค่อยเคลื่อนไหว">ไม่ค่อยเคลื่อนไหว</option>
                  <option value="เบา">เบา</option>
                  <option value="ปานกลาง">ปานกลาง</option>
                  <option value="หนัก">หนัก</option>
                  <option value="นักกีฬา">นักกีฬา</option>
                </select>
              </div>
            </div>
          </div>

          {/* รหัสผ่าน */}
          <div className="bg-white/5 p-4 sm:p-6 rounded-lg dark:bg-white/50">
            <h2 className="text-xl font-semibold text-white mb-4 dark:text-black/60">รหัสผ่าน</h2>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                required
                value={formData.password}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-white/10 border border-gray-300/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:border-black/20 dark:text-white/80"
                placeholder="รหัสผ่าน *"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white dark:text-gray-600 dark:hover:text-white"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {/* ปุ่มสมัครสมาชิก */}
          <div className="flex flex-col items-center">
            <button
              type="submit"
              className="mt-4 w-full sm:w-[300px] bg-black/50 hover:bg-black/80 text-white font-semibold py-3 rounded-lg transition duration-200"
            >
              สมัครสมาชิก
            </button>
            <p className="text-center text-gray-200 mt-6">
              มีบัญชีอยู่แล้ว?{" "}
              <span
                onClick={() => navigate("/login")}
                className="text-blue-300 hover:text-blue-400 cursor-pointer dark:text-blue-600 dark:hover:text-blue-800"
              >
                เข้าสู่ระบบ
              </span>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
