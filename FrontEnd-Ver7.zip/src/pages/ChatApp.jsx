import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import ReactMarkdown from "react-markdown";
import {
  Copy,
  Send,
  Trash2,
  MessageSquare,
  CopyPlus,
  History,
  FilePenLine,
  CircleUserRound,
  Mail,
} from "lucide-react";
import Swal from "sweetalert2";
import { useSearchParams } from "react-router-dom";

const API_BASE = "https://2f31-34-48-84-94.ngrok-free.app";

const ChatApp = () => {
  const messagesEndRef = useRef(null);
  const [chats, setChats] = useState([]);
  const [selectedChatId, setSelectedChatId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [searchParams] = useSearchParams();
  const chatId = searchParams.get("chat_id");
  const [userData, setUserData] = useState(null);
  const [chatTitle, setChatTitle] = useState("");
  const [chatCreatedAt, setChatCreatedAt] = useState("");

  const token = localStorage.getItem("token");
  const headers = {
    Authorization: `Bearer ${token}`,
    "ngrok-skip-browser-warning": "true",
  };

  const groupChatsByTime = (chats) => {
    const now = new Date();
    const oneDay = 24 * 60 * 60 * 1000;
    const sevenDays = 7 * oneDay;
    const thirtyDays = 30 * oneDay;

    const groups = {
      วันนี้: [],
      สัปดาห์นี้: [],
      เดือนนี้: [],
      เก่ากว่านั้น: [],
    };

    chats.forEach((chat) => {
      const updatedAt = new Date(
        typeof chat.updated_at === "string"
          ? chat.updated_at
          : chat.updated_at._seconds * 1000
      );
      const diff = now - updatedAt;

      if (diff <= oneDay) {
        groups["วันนี้"].push(chat);
      } else if (diff <= sevenDays) {
        groups["สัปดาห์นี้"].push(chat);
      } else if (diff <= thirtyDays) {
        groups["เดือนนี้"].push(chat);
      } else {
        groups["เก่ากว่านั้น"].push(chat);
      }
    });

    // เรียงใหม่ -> เก่า
    Object.values(groups).forEach((list) =>
      list.sort((a, b) => {
        const t1 = new Date(
          typeof a.updated_at === "string"
            ? a.updated_at
            : a.updated_at._seconds * 1000
        );
        const t2 = new Date(
          typeof b.updated_at === "string"
            ? b.updated_at
            : b.updated_at._seconds * 1000
        );
        return t2 - t1;
      })
    );

    return groups;
  };

  const renameChat = async (chat_id, oldTitle) => {
    // ✅ Scroll กลับขึ้นบนก่อนเปิด modal
    window.scrollTo({ top: 0, behavior: "smooth" });

    const result = await Swal.fire({
      title: "เปลี่ยนชื่อแชท",
      input: "text",
      inputLabel: "ชื่อใหม่",
      inputValue: oldTitle,
      showCancelButton: true,
      confirmButtonText: "บันทึก",
      cancelButtonText: "ยกเลิก",
    });

    if (result.isConfirmed && result.value.trim()) {
      try {
        await axios.patch(
          `${API_BASE}/rename-chat/${chat_id}`,
          {
            title: result.value.trim(),
          },
          { headers }
        );
        fetchChats();
        Swal.fire("สำเร็จ!", "ชื่อแชทถูกเปลี่ยนแล้ว", "success");
        window.location.reload();
      } catch (err) {
        Swal.fire("ผิดพลาด", "ไม่สามารถเปลี่ยนชื่อได้", "error");
      }
    }
  };

  const fetchUserData = async () => {
    try {
      const token = localStorage.getItem("token"); // ✅ ดึง token มาใช้ตรงนี้
      const response = await axios.get(
        "http://localhost:5000/api/auth/getuser",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setUserData(response.data);
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "เกิดข้อผิดพลาด",
        text: "ไม่สามารถดึงข้อมูลผู้ใช้ได้",
      });
    }
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  // ✅ ดึงแชททั้งหมดของ user
  const fetchChats = async () => {
    try {
      const res = await axios.get(`${API_BASE}/get-my-chats`, { headers });
      setChats(res.data);
    } catch (error) {
      console.error("❌ ดึงแชทไม่สำเร็จ:", error);
      setChats([]);
    }
  };

  // ✅ ดึงแชทจาก chat_id
  const fetchChatById = async () => {
    try {
      const res = await axios.get(`${API_BASE}/get-chat/${chatId}`, {
        headers,
      });
      setMessages(res.data.messages || []);
    } catch (err) {
      console.error("❌ โหลดแชทไม่สำเร็จ", err);
      setMessages([]);
    }
  };

  useEffect(() => {
    if (chatId) {
      setSelectedChatId(chatId);
      fetchChatById();
    }
  }, [chatId]);

  useEffect(() => {
    fetchChats();
  }, []);

  const createChat = async () => {
    try {
      const res = await axios.post(
        `${API_BASE}/create-chat`,
        { title: "แชทใหม่", messages: [] },
        { headers }
      );
      setSelectedChatId(res.data.chat_id);
      setMessages([{ role: "assistant", content: res.data.message }]);
      fetchChats();
    } catch (err) {
      console.error("❌ สร้างแชทไม่สำเร็จ", err);
    }
  };

  const deleteChat = async (id) => {
    const result = await Swal.fire({
      title: "คุณแน่ใจหรือไม่?",
      text: "คุณต้องการลบแชทนี้ใช่หรือไม่?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "ยืนยัน",
      cancelButtonText: "ยกเลิก",
    });

    if (result.isConfirmed) {
      try {
        await axios.delete(`${API_BASE}/delete-chat/${id}`, { headers });
        if (selectedChatId === id) {
          setSelectedChatId(null);
          setMessages([]);
        }
        fetchChats();
        Swal.fire("ลบสำเร็จ!", "แชทนี้ถูกลบเรียบร้อยแล้ว", "success");
        window.location.reload();
      } catch (error) {
        Swal.fire("เกิดข้อผิดพลาด", "ไม่สามารถลบแชทได้", "error");
      }
    }
  };

  const sendMessage = async () => {
    if (!newMessage || !selectedChatId) return;

    const userMsg = { role: "user", content: newMessage };
    setMessages((prev) => [...prev, userMsg]);
    setNewMessage("");
    setIsTyping(true);

    try {
      const res = await axios.post(
        `${API_BASE}/ask/${selectedChatId}`,
        {
          question: newMessage,
        },
        { headers }
      );

      const aiMsg = { role: "assistant", content: res.data.response };
      setMessages((prev) => [...prev, aiMsg]);
      fetchChats();
    } catch (error) {
      console.error("❌ ส่งข้อความไม่สำเร็จ:", error);
    } finally {
      setIsTyping(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className="flex h-screen dark:bg-gray-100">
      {/* Sidebar */}
      <div className="flex flex-col w-1/6 h-[full]  mt-[80px] p-4 border-r border-blue-500/40 bg-black/50 dark:bg-gray-900/10">
        <div>
          <h2 className="flex items-center gap-2 text-xl font-bold mb-2 text-white dark:text-black/80" >
            <MessageSquare /> แชททั้งหมด
          </h2>
          <div className="mb-4">
            <button
              className="flex items-center gap-3 justify-center mt-2 bg-green-500 rounded-md px-2 py-1 w-full hover:bg-green-600"
              onClick={createChat}
            >
              เพิ่มแชทใหม่ <CopyPlus />
            </button>
          </div>
          <h2 className="flex items-center border-t border-blue-500/40 gap-2 text-xl font-bold mb-2 mt-2 pt-4 text-white dark:text-black/80">
            <History /> ประวัติการสนทนา
          </h2>
        </div>
        <div className="flex-1 overflow-y-auto pr-1 mt-2 mb-2">
          {Object.entries(groupChatsByTime(chats)).map(([section, group]) =>
            group.length > 0 ? (
              <div key={section}>
                <h3 className="text-white text-xs font-bold mb-1 mt-2 pl-1 dark:text-black/50">
                  {section}
                </h3>
                {group.map((chat) => (
                  <div
                    key={chat.chat_id}
                    className={`bg-gray-800/5 px-2 py-1 mb-4 rounded-md border-b border-blue-500/40 cursor-pointer hover:bg-blue-500/40 dark:bg-gray-900/10 dark:hover:bg-gray-900/50  ${
                      selectedChatId === chat.chat_id
                        ? "bg-gray-500/90 dark:bg-gray-900/50"
                        : "bg-gray-100"
                    }`}
                    onClick={async () => {
                      setSelectedChatId(chat.chat_id);
                      try {
                        const res = await axios.get(
                          `https://firestore.googleapis.com/v1/projects/history--fitchat-ai/databases/(default)/documents/chats/${chat.chat_id}`
                        );
                        const msgList =
                          res.data.fields.messages.arrayValue.values.map(
                            (m) => ({
                              role: m.mapValue.fields.role.stringValue,
                              content: m.mapValue.fields.content.stringValue,
                            })
                          );
                        setMessages(msgList);
                        const title = res.data.fields.title?.stringValue || "";
                        const createdAt =
                          res.data.fields.created_at?.timestampValue || null;
                        setChatTitle(title);
                        setChatCreatedAt(createdAt);
                      } catch (error) {
                        console.error("❌ โหลดข้อความล้มเหลว", error);
                      }
                    }}
                  >
                    <div className="flex justify-between items-center text-white/80 dark:text-black/80 dark:hover:text-white">
                      <span
                        className="truncate"
                        onDoubleClick={(e) => {
                          e.stopPropagation();
                          renameChat(chat.chat_id, chat.title);
                        }}
                        title="ดับเบิ้ลคลิกเพื่อเปลี่ยนชื่อ"
                      >
                        {chat.title}
                      </span>
                      <div className="flex justify-between items-center text-white/70">
                        <span className="truncate max-w-[140px]"></span>
                        <div className="flex gap-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              renameChat(chat.chat_id, chat.title);
                            }}
                            className="text-gray-700 hover:text-blue-500"
                            title="เปลี่ยนชื่อ"
                          >
                            <FilePenLine size={18} />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteChat(chat.chat_id);
                            }}
                            className="text-gray-700 text-sm hover:text-red-500"
                            title="ลบแชท"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : null
          )}
        </div>
        {userData && (
          <div className="border-t border-blue-500/40 pt-3 text-sm text-white dark:text-black/70">
            <div className="flex items-center gap-2">
              <CircleUserRound size={15} />{" "}
              <span className="font-semibold">{userData.first_name}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-300 dark:text-black/70">
              <Mail size={15} /> {userData.email}
            </div>
          </div>
        )}
      </div>

      {/* Chat Window */}
      <div className="flex-1 flex flex-col h-[calc(90vh-80px)] mt-[120px] m-6 p-6 rounded-3xl border border-blue-500/40 bg-black/50 shadow-2xl dark:bg-black/10">
        {/* ✅ ส่วน Header ของแชท */}
        {selectedChatId && (
          <div className="flex justify-between items-center border-b border-blue-500/50 pb-2 mb-4">
            <div>
              <h2 className="text-white text-xl font-bold dark:text-black/70">
                {chatTitle || "ชื่อแชท"}
              </h2>
              <p className="text-gray-400 text-sm dark:text-black/50">
                สร้างเมื่อ:{" "}
                {chatCreatedAt
                  ? new Date(chatCreatedAt).toLocaleString("th-TH")
                  : "-"}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => renameChat(selectedChatId, chatTitle)}
                className="text-sm text-gray-400 hover:text-blue-500"
              >
                <FilePenLine size={30} />
              </button>
              <button
                onClick={() => deleteChat(selectedChatId)}
                className="text-sm text-gray-400 hover:text-red-500"
              >
                <Trash2 size={30}/>
              </button>
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto mb-4 space-y-4 p-4">
          {Array.isArray(messages) &&
            messages.map((m, idx) => (
              <div
                key={idx}
                className={`w-full flex ${
                  m.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`whitespace-pre-wrap break-words max-w-[80%] p-3 rounded-2xl text-black shadow ${
                    m.role === "user" ? "bg-blue-200" : "bg-gray-100"
                  }`}
                >
                  <div className="text-sm mb-1 ">
                    <strong>{m.role === "user"}</strong>
                    <ReactMarkdown
                      components={{
                        a: ({ node, ...props }) => (
                          <a
                            {...props}
                            className="text-blue-600 underline"
                            target="_blank"
                            rel="noopener noreferrer"
                          />
                        ),
                        p: ({ node, ...props }) => (
                          <p {...props} className="whitespace-pre-wrap" />
                        ),
                      }}
                    >
                      {m.content}
                    </ReactMarkdown>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-500 mt-2">
                    <span>
                      {new Date().toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                    <button
                      onClick={() => navigator.clipboard.writeText(m.content)}
                      className="flex items-center gap-1 hover:text-blue-500"
                    >
                      <Copy size={15} />
                      คัดลอก
                    </button>
                  </div>
                </div>
              </div>
            ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-200  text-gray-700 text-sm px-4 py-2 rounded-2xl shadow max-w-[60%] animate-pulse">
                ...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        {selectedChatId && (
          <div className="flex">
            <input
              type="text"
              className="flex-1 border text-black bg-gray-100 p-2 mr-2 rounded-xl shadow"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="พิมพ์ข้อความ..."
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            />
            <button
              className="bg-blue-500 text-white px-4 rounded-xl shadow"
              onClick={sendMessage}
            >
              <Send />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatApp;
