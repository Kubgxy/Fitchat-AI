import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const Home = () => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/chatapp");
  };
  return (
    <div className="relative min-h-screen flex items-center dark:bg-gray-100  transition-colors duration-300">
      {/* Background overlay */}
      <div className="absolute inset-0" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center py-16">
          {/* ข้อความด้านซ้าย */}
          <div className="text-center md:text-left">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6 leading-snug dark:text-black">
              FitChat AI - ผู้ช่วยดูแลสุขภาพอัจฉริยะ
            </h1>
            <p className="text-lg sm:text-xl   text-gray-400 mb-8 max-w-xl mx-auto md:mx-0 dark:text-black">
              ปรึกษาเรื่องสุขภาพ, การออกกำลังกาย และโภชนาการ ด้วย AI
              ที่เข้าใจคุณ
            </p>
            <button
              onClick={handleClick}
              className="lg:w-[500px] px-6 py-3 bg-black/50 border-[1px] border-blue-500/40 hover:bg-black/80 rounded-lg text-white font-medium transition duration-200 dark:text-black dark:bg-gray-400 dark:hover:bg-gray-700/70 dark:hover:text-white" 
            >
              เริ่มต้นใช้งาน
            </button>
          </div>

          {/* โลโก้ด้านขวา */}
          <div className="flex flex-col items-center justify-center">
            <motion.img
              src="/src/assets/Logo4.png"
              alt="AI Chat"
              className="w-[200px] h-[200px] sm:w-[250px] sm:h-[250px] lg:w-[300px] lg:h-[300px]"
              animate={{ y: [0, -20, 0] }}
              transition={{
                duration: 0.6,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut",
              }}
            />
            <h1
              className="text-5xl sm:text-6xl font-bold text-white drop-shadow-[0_0_15px_rgba(173,216,250,0.7)] text-center transition-all duration-300 dark:text-black dark:drop-shadow-[0_0_15px_rgba(0,0,0,0.7)]"
              style={{ fontFamily: "'Audiowide', sans-serif" }}
            >
              FitChat AI
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
