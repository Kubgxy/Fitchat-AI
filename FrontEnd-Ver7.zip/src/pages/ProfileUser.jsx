import React, { useState, useEffect } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import { User, Edit2, Save } from "lucide-react";

const Profile = () => {
  const [userData, setUserData] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone_number: "",
    age: "",
    gender: "",
    height: "",
    weight: "",
    health_goal: "",
    activity_level: "",
    diet_preference: "",
  });

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const token = localStorage.getItem("token"); // ✅ ดึง token มาใช้ตรงนี้
      const response = await axios.get(
        "http://localhost:5000/api/auth/getuser",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setUserData(response.data);
      setFormData(response.data);
      setLoading(false);
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "เกิดข้อผิดพลาด",
        text: "ไม่สามารถดึงข้อมูลผู้ใช้ได้",
      });
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      await axios.patch("http://localhost:5000/api/auth/editdata", formData, {
        headers: { Authorization: `Bearer ${token}` },
      });

      await Swal.fire({
        icon: "success",
        title: "สำเร็จ",
        text: "อัพเดทข้อมูลเรียบร้อยแล้ว",
        showConfirmButton: false,
        timer: 1500,
      });

      setIsEditing(false);
      fetchUserData(); // รีโหลดข้อมูลใหม่
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "เกิดข้อผิดพลาด",
        text: error.response?.data?.message || "ไม่สามารถอัพเดทข้อมูลได้",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen  py-8 h-screen dark:bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="h-[800px]  mt-20 mx-auto p-5 rounded-xl ">
          <div className="flex justify-between items-center  mb-8">
            <div className="flex  items-center space-x-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center dark:bg-black/30">
                <User className="w-8 h-8 text-white " />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white dark:text-black/80">
                  โปรไฟล์ของฉัน
                </h1>
                <p className="text-gray-200 dark:text-black/60">
                  จัดการข้อมูลส่วนตัวของคุณ
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center space-x-2 px-4 py-2 bg-black/90 text-white rounded-lg border border-blue-500/40 hover:bg-white/30 transition dark:bg-black/20 dark:text-white/80 dark:hover:bg-black/40"
            >
              {isEditing ? (
                <Save className="w-4 h-4" />
              ) : (
                <Edit2 className="w-4 h-4" />
              )}
              <span>{isEditing ? "บันทึก" : "แก้ไข"}</span>
            </button>
          </div>

          <div className="pt-27 h-[600px] rounded-xl overflow-y-auto ">
            <div className="max-w-[1600px] mx-auto  rounded-xl shadow-xl p-8 ">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* ข้อมูลส่วนตัว */}
                <div className="bg-black/20 p-6 rounded-lg border border-blue-500/40 dark:bg-black/10">
                  <h2 className="text-xl font-semibold text-white mb-4 dark:text-black/60">
                    ข้อมูลส่วนตัว
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ">
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        ชื่อ
                      </label>
                      <input
                        type="text"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10 border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20  dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        นามสกุล
                      </label>
                      <input
                        type="text"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        อีเมล
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* ข้อมูลสุขภาพ */}
                <div className="bg-black/20 p-6 rounded-lg border border-blue-500/40 dark:bg-black/10">
                  <h2 className="text-xl font-semibold text-white mb-4 dark:text-black/60">
                    ข้อมูลสุขภาพ
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        อายุ
                      </label>
                      <input
                        type="text"
                        name="age"
                        value={formData.age}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        เพศ
                      </label>
                      <input
                        type="text"
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        ส่วนสูง
                      </label>
                      <input
                        type="text"
                        name="height"
                        value={formData.height}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        น้ำหนัก
                      </label>
                      <input
                        type="text"
                        name="weight"
                        value={formData.weight}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        เป้าเหมาย
                      </label>
                      <input
                        type="text"
                        name="health_goal"
                        value={formData.health_goal}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        ระดับการออกกำลังกาย
                      </label>
                      <input
                        type="text"
                        name="activity_level"
                        value={formData.activity_level}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-200 mb-2 dark:text-black/60">
                        ระดับการออกกำลังกาย
                      </label>
                      <input
                        type="text"
                        name="diet_preference"
                        value={formData.diet_preference}
                        onChange={handleChange}
                        disabled={!isEditing}
                        className="w-full px-4 py-2 bg-white/10  border border-blue-500/40 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-black/20 dark:text-white"
                      />
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          {isEditing && (
            <div className="flex justify-center mt-5 ">
              <button
                type="submit"
                className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
              >
                บันทึกการเปลี่ยนแปลง
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
