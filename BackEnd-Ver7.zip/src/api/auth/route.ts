import express, { Request, Response } from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from "../../models/User";
import { verifyToken } from "../../middleware/auth";

const auth = express.Router();
const SECRET_KEY = process.env.SECRET_KEY || "fitchat";

//API Register
auth.post("/register", async (req: Request, res: Response) => {
  const {
    user_id,
    age,
    gender,
    height,
    weight,
    health_goal,
    activity_level,
    medical_conditions,
    diet_preference,
    exercise_history,
    progress_metrics,
    first_name,
    last_name,
    email,
    phone_number,
    username,
    password,
  } = req.body;

  try {
    // ตรวจสอบข้อมูลที่จำเป็น
    if (
      !user_id ||
      !age ||
      !gender ||
      !height ||
      !weight ||
      !health_goal ||
      !activity_level ||
      !username ||
      !password ||
      !email ||
      !first_name ||
      !last_name
    ) {
      return res.status(400).json({
        message: "กรุณากรอกข้อมูลให้ครบถ้วน",
        missingFields: {
          user_id: !user_id,
          age: !age,
          gender: !gender,
          height: !height,
          weight: !weight,
          health_goal: !health_goal,
          activity_level: !activity_level,
          username: !username,
          password: !password,
          email: !email,
          first_name: !first_name,
          last_name: !last_name,
        },
      });
    }

    // ตรวจสอบความถูกต้องของข้อมูล

    if (phone_number && !/^[0-9]{10}$/.test(phone_number)) {
      return res
        .status(400)
        .json({ message: "เบอร์โทรศัพท์ต้องเป็นตัวเลข 10 หลัก" });
    }

    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
    if (!passwordRegex.test(password)) {
      return res.status(400).json({
        message:
          "รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษร และประกอบด้วยตัวอักษรและตัวเลข",
      });
    }

    // ตรวจสอบการซ้ำของข้อมูล
    const existingUser = await User.findOne({
      $or: [{ username }, { email }, { phone_number }, { user_id }],
    });

    if (existingUser) {
      let message = "";
      if (existingUser.username === username)
        message = "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว";
      else if (existingUser.email === email) message = "อีเมลนี้ถูกใช้งานแล้ว";
      else if (existingUser.phone_number === phone_number)
        message = "เบอร์โทรศัพท์นี้ถูกใช้งานแล้ว";
      else if (existingUser.user_id === user_id)
        message = "รหัสผู้ใช้นี้ถูกใช้งานแล้ว";

      return res.status(400).json({ message });
    }

    // ตรวจสอบข้อมูลตัวเลข
    if (age < 0 || age > 120) {
      return res.status(400).json({ message: "อายุไม่ถูกต้อง" });
    }

    if (height <= 0) {
      return res.status(400).json({ message: "ส่วนสูงไม่ถูกต้อง" });
    }

    if (weight <= 0) {
      return res.status(400).json({ message: "น้ำหนักไม่ถูกต้อง" });
    }

    // สร้างผู้ใช้ใหม่
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({
      user_id,
      age,
      gender,
      height,
      weight,
      health_goal,
      activity_level,
      medical_conditions: medical_conditions || [],
      diet_preference,
      exercise_history: exercise_history || [],
      progress_metrics: progress_metrics || {},
      first_name,
      last_name,
      email,
      phone_number,
      username,
      password: hashedPassword,
    });

    await newUser.save();

    const token = jwt.sign({ userId: newUser._id }, SECRET_KEY, {
      expiresIn: "1h",
    });

    res.status(201).json({
      message: "ลงทะเบียนสำเร็จ",
      token,
      user: {
        id: newUser._id,
        username: newUser.username,
        first_name: newUser.first_name,
        last_name: newUser.last_name,
        email: newUser.email,
      },
    });
  } catch (error: unknown) {
    // ใช้ unknown type
    console.error("Error in registration:", error);
    let errorMessage = "เกิดข้อผิดพลาดในระบบ";

    if (error instanceof Error) {
      if ((error as any).code === 11000) {
        // type assertion สำหรับ Mongoose error
        errorMessage = "ข้อมูลซ้ำซ้อน";
      }
    }

    res.status(500).json({
      message: errorMessage,
      error:
        process.env.NODE_ENV === "development"
          ? error instanceof Error
            ? error.message
            : String(error)
          : undefined,
    });
  }
});

//API Login
auth.post("/login", async (req: Request, res: Response) => {
  const { username, password } = req.body;

  try {
    // ตรวจสอบว่ามีข้อมูลครบไหม
    if (!username || !password) {
      return res
        .status(400)
        .json({ message: "Please provide username and password" });
    }

    // ค้นหา user จาก username
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    // ตรวจสอบ password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    // สร้าง token

    const payload = {
      userId: user.user_id,
      id: user._id,
      username: user.username,
      email: user.email,
    };
    
    const SECRET_KEY = "fitchat";
    
    const token = jwt.sign(payload, SECRET_KEY, { expiresIn: "1h" });
    console.log("TOKEN = ", token)
    // ส่งข้อมูลกลับ
    res.status(200).json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        userId: user.user_id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error("Error in login:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Logout API
auth.post("/logout", (req: Request, res: Response) => {
  // ในกรณีที่ใช้ LocalStorage → เราแค่ตอบกลับเฉย ๆ ว่า Logout สำเร็จ
  // แต่ถ้าใช้ Cookie → สามารถล้าง cookie ได้ที่นี่ด้วย

  res.status(200).json({
    message: "Logout successful",
  });
});


// ตัวอย่าง Express
auth.get("/getuser", verifyToken, async (req: Request, res: Response) => {
  try {
    const { userId } = req.user; // ✅ ดึงจาก req.user ได้แน่นอน
    console.log("🪪 userId ที่ได้จาก token:", userId);

    const user = await User.findOne({ user_id: userId });
    if (!user) {
      return res.status(404).json({ message: "ไม่พบผู้ใช้" });
    }

    res.json(user);
  } catch (error) {
    console.error("❌ เกิดข้อผิดพลาดใน getuser:", error);
    res.status(500).json({ message: "เกิดข้อผิดพลาดในฝั่งเซิร์ฟเวอร์" });
  }
});



auth.patch("/editdata", verifyToken, async (req: Request, res: Response) => {
  try {
    const {
      first_name,
      last_name,
      email,
      phone_number,
      age,
      gender,
      height,
      weight,
      health_goal,
      activity_level,
      diet_preference,
      password
    } = req.body;

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้" });
    }

    // อัพเดทข้อมูลทั่วไป
    if (first_name) user.first_name = first_name;
    if (last_name) user.last_name = last_name;
    if (email) user.email = email;
    if (phone_number) user.phone_number = phone_number;
    if (age) user.age = age;
    if (gender) user.gender = gender;
    if (height) user.height = height;
    if (weight) user.weight = weight;
    if (health_goal) user.health_goal = health_goal;
    if (activity_level) user.activity_level = activity_level;
    if (diet_preference) user.diet_preference = diet_preference;

    // ถ้ามีการเปลี่ยนรหัสผ่าน
    if (password) {
      user.password = await bcrypt.hash(password, 10);
    }

    await user.save();
    res.json({ message: "อัพเดทข้อมูลสำเร็จ" });
  } catch (error) {
    res.status(500).json({ message: "เกิดข้อผิดพลาดในการอัพเดทข้อมูล" });
  }
});

export default auth;
