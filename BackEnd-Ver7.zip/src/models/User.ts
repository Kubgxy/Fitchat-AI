import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    // ข้อมูลส่วนตัว
    user_id: {
      type: String,
      unique: true,
      required: true,
    },
    first_name: {
      type: String,
      required: true,
      trim: true,
    },
    last_name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      validate: {
        validator: function (v) {
          return /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(v);
        },
        message: "กรุณากรอกอีเมลให้ถูกต้อง",
      },
    },
    phone_number: {
      type: String,
      default: null,
    },
    username: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },

    // ข้อมูลประชากร
    age: {
      type: Number,
      min: 0,
      max: 120,
      required: true,
    },
    gender: {
      type: String,
      default: "เลือกเพศ",
      enum: ["ชาย", "หญิง", "อื่นๆ"],
      required: true,
    },

    // ข้อมูลร่างกาย
    height: {
      type: Number,
      min: 0,
      required: true,
    },
    weight: {
      type: Number,
      min: 0,
      required: true,
    },

    // ข้อมูลสุขภาพ
    health_goal: {
      type: String,
      enum: [
        "ลดน้ำหนัก",
        "เพิ่มกล้ามเนื้อ",
        "เพิ่มความแข็งแรง",
        "เพิ่มความอดทน",
        "จัดการโรคประจำตัว",
        "เพิ่มสมรรถภาพ",
        "อื่นๆ",
      ],
      required: true,
    },
    activity_level: {
      type: String,
      enum: ["ไม่ค่อยเคลื่อนไหว", "เบา", "ปานกลาง", "หนัก", "นักกีฬา"],
      required: true,
    },
    medical_conditions: [
      {
        type: String,
        trim: true,
      },
    ],
    diet_preference: {
      type: String,
      enum: ["ทั่วไป", "มังสวิรัติ", "วีแกน", "คีโต", "พาเลโอ", "อื่นๆ"],
    },
    exercise_history: [
      {
        type: String,
        trim: true,
      },
    ],
    progress_metrics: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },

    // ข้อมูลการสร้างและอัพเดท
    created_at: {
      type: Date,
      default: Date.now,
    },
    updated_at: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

// เพิ่ม index เพื่อการค้นหาที่มีประสิทธิภาพ
userSchema.index({ email: 1, username: 1 });

const User = mongoose.model("User", userSchema);

export default User;
